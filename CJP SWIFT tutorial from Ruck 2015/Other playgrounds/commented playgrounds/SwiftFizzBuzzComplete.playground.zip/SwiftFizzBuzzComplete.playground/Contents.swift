/*:
# Fizz buzz playground

Fizz buzz is a game where when counting avery number that is diviable by 3 is replaced as fizz and if divisable by 5 buzz. If divisable by both then it becomes fizzbuzz. 
Create a loop that counts to 100 and replaces numbers with fizz and buzz as needed.
*/

for var i=1; i<101; i++
{
//: `a % b` returns the remainder of `a` divided by `b`

//: Use `println(<String>)` to print something to the console

    if ((i%3==0) && (i%5==0))
    {
        println("Fizz Buzz")
    }
    else if i%3==0
    {
        println("Fizz")
    }
    else if i%5==0
    {
        println("Buzz")
    }
    else
    {
        println(i)
    }
}
