/*:
# Deck of Cards
A playground to explore enums, structs and random numbers

Lets start with by making suits
*/

enum Suit {
    case Spades, Hearts, Diamonds, Clubs
    func simpleDescription() -> String {
        switch self {
        case .Spades:
            return "spades"
        case .Hearts:
            return "hearts"
        case .Diamonds:
            return  "diamonds"
        case .Clubs:
            return "clubs"
        }
    }
    func suitColour() -> String {
        switch self {
        case .Spades, .Clubs:
            return "Black"
        case .Hearts, .Diamonds:
            return "Red"
        }
    }
}

/*:
Now that we have suits we need ranks.

Use an `enum` called "Rank" of type `Int` to create rankings Ace -> King
*/


/*:
Into the above `enum` add the following `func` to ensure the rank is presented properly.

    func simpleDescription() -> String {
        switch self {
        case .Ace:
            return "Ace"
        case .Jack:
            return "Jack"
        case .Queen:
            return "Queen"
        case .King:
            return "King"
        default:
            return String(self.rawValue)
        }
    }
*/

/*:
Now a `struct` can be used for each card.

Create a struct called "Card" that has a rank of type `Rank` and a suit of type `Suit`

Then add a `func` called "simpleDescription" that returns a string of the simpleDescription of both Rank and Suit to give a description of a card. Such as "The 3 of Clubs"

*/

//:Now we can have a deck of cards. This can be an array of type `Card`. Initailise this now.

var deckOfCards = [Card]()

//:We need to initailise the whole deck of cards
//:First start a for loop for the suits
for var j=0; j<4; j++
{
    var currentSuit = Suit.Spades
    switch j
    {
    case 0:
        currentSuit = .Spades
    case 1:
        currentSuit = .Hearts
    case 2:
        currentSuit = .Diamonds
    case 3:
        currentSuit = .Clubs
    default:
        break
    }
    
//:Then start a loop for the rankings in the suit

    for var k=0; k<13; k++
    {
        if (Rank(rawValue: (k+1)) != nil)
        {
            var tmpRank = Rank(rawValue: (k+1))
            deckOfCards.append(Card(rank: tmpRank!, suit: currentSuit))
            deckOfCards[((j*13)+k)].simpleDescription()
        }
        else
        {
            break
        }
    }
}
//: For the arc4random function the UIKit module needs to imported
import UIKit
/*:
Now lets start to play with the cards
-------------------------------------
To get a random number `arc4random()` is used. It is automatically seeding and use `arc4random_uniform(<maximum Number>)` to get a number betweeen 1 and the maximum. It creates a `UInt32` so needs to be cast as an `Int` when using arrays.
*/
//: Write a function that will draw a random card from the deck
func drawAnyCard() -> String
{
    return
}

//: Write a function that will draw a specific card from the deck
func drawCardX(position: Int) -> String
{
    return
}

//: Write a function that will shuffle the deck
func shuffleDeck()
{

    
}



