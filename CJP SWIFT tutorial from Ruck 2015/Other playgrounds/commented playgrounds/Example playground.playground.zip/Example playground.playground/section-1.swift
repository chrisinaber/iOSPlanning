// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let x = ["a", "b"]
let y = x.count

let z = arc4random_uniform(UInt32(y))
let a = random() % y

var myLabel = UILabel (frame: CGRectMake(0.0, 0.0, 200.0, 100.0))
myLabel.text = str
myLabel.backgroundColor = UIColor.redColor()myLabel.textColor = UIColor.whiteColor()myLabel.text = "Math is easy: \(6454 + 24323)"
