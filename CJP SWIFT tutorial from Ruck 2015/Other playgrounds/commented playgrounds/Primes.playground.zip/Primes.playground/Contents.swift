//:# Playground exploring prime numbers

//: Setting up variables
var numberOfPrimes = 1  // 2 is a prime
let topNum = 2500


for num in 3...topNum {
    var stillPrime = true
    
    var tryNum = 2
    while (tryNum * tryNum <= num)  &&
          stillPrime{
        var x = num % tryNum
        if num % tryNum == 0 {
           stillPrime = false
        }
        tryNum++
    }
    if stillPrime {
       let str = "\(num) is prime"
        numberOfPrimes++
    }
  numberOfPrimes
}
