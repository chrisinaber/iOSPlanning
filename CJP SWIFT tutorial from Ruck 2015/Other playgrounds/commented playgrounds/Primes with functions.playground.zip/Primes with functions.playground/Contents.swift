//: A playground - noun: a place where people can play

var numberOfPrimes = 1  // 2 is a prime
let topNum = 25

func isPrime( number: Int ) -> Bool {
    var answer = true
    var tryNum = 2
    while (tryNum * tryNum <= number) && answer {
        let val = number % tryNum
        if number % tryNum == 0 {
                answer = false
        }
        tryNum++
    }
    return answer
}

for num in 3...topNum {
    if isPrime(num) {
        var ans = "\(num) is prime"
        numberOfPrimes++
    }
    
  numberOfPrimes
}
