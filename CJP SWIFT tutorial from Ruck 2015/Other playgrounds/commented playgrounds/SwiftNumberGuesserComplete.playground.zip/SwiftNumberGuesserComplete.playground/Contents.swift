/*:
# Number Guesser written for Ruck 2015
*/
//:Start by defining the varibles needed
//: Enter the answer you want the computer to look for
let answerNumber = 67
//:The varible `previousGuess` starts as the maxium
var previousGuess = 100
//:The `currentGuess` starts as half of maximum
var currentGuess = 50

var temporyNumber = 0
//:Set up a loop that continues until the `currentGuess` equals the the `answerNumber`
while currentGuess != answerNumber
{
//:Compare `currentGuess` agaisnt `answerNumber`
//:then adjust your `currentGuess` accordingly
//:`abs()` gives you the absolute value
    temporyNumber = currentGuess
    if currentGuess > answerNumber
    {
        currentGuess = currentGuess - (abs((previousGuess - currentGuess)) / 2)
        previousGuess = temporyNumber
        if(currentGuess == previousGuess){currentGuess--}
    }
    else
    {
        currentGuess = (abs((previousGuess - currentGuess)) / 2) + currentGuess
        previousGuess = temporyNumber
        if(currentGuess == previousGuess){currentGuess++}
    }
    
}
//:# Now as a function
//:Write a function called difference that takes two values and returns the difference
func difference(num1: Int, num2: Int) -> Int
{
    return (abs((num1 - num2)) / 2)
}

//:Now write a function that takes two numbers the target number and the maxium number and guesses the number.
func guessNumber(numberTarget: Int, maximumNumber: Int)
{
    var currentNumber = maximumNumber / 2
    var previousNumber = maximumNumber
    var tmpNum = 0
    while currentNumber != numberTarget
    {
        tmpNum = currentNumber
        if currentNumber > numberTarget
        {
            currentNumber = currentNumber - difference(previousNumber, currentNumber)
            previousNumber = tmpNum
            if(currentNumber == previousNumber){currentNumber--}
        }
        else
        {
            currentNumber = difference(previousNumber, currentNumber)
                + currentNumber
            previousNumber = tmpNum
            if(currentNumber == previousNumber){currentNumber++}
        }
    }
}


