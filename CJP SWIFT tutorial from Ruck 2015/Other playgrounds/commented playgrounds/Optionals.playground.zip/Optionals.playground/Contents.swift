//: Optionals Playground - a brief overview of optionals

import UIKit
//: Let's set up some varibles.
var pets = [ "Dave": "Goldfish", "Chaz": "Dog", "Idris": "Guinea Pig"]
pets["Murphy"] = "Guinea Pig"   //Add Murphy to the list of pets

//:The `optional` is defined
var animalRef: String? = pets["Murphy"]

//:Use a conditional in comparison will say if it has value or not
println(animalRef == nil)

//: Force unwrapping
if (animalRef != nil) {println( animalRef!) }
else { println( "Animal Unknown" ) }

//: Better unwrapping
if let animal = animalRef { println(animal) }
else { println( "Animal Unknown") }

//:Trying to access value not key of dictionary
animalRef = pets["Dog"]
var animalRef2 = pets["Cat"]

if let animal = animalRef, let animal2 = animalRef2 { println(animal, animal2)
}
else { println( "Animals Unknown") }

//: Now the key of the dictionary
animalRef = pets["Chaz"]
animalRef2 = pets["Murphy"]

if let animal = animalRef, let animal2 = animalRef2 { println(animal, animal2)
}
else { println( "Animals Unknown") }


